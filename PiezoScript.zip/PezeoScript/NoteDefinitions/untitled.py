import pygame, sys
from pygames.locals import *

player = pygame.image.load("")
imgRect = player.get_rect()

while True:
	screen.fill(black)
	screen.blit(player,imgRect)
	screen.display.flip()
