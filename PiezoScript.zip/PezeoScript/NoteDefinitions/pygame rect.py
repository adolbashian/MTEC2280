pygame.draw.rect(Surface, color, Rect, width=0): 
	return Rect
	
draw a rectangle shape
